"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';

/**
 * Sidebar renders the primary navigation for authenticated users.
 * It displays a vertical list of links to the dashboard, messages,
 * video visits and billing information.  The active route is
 * highlighted to provide feedback on the current location.  Icons
 * could be added here in a later phase using an icon library such
 * as Heroicons; for simplicity, this MVP uses plain text labels.
 */
export default function Sidebar() {
  const pathname = usePathname();
  const links = [
    { href: '/dashboard', label: 'Dashboard' },
    { href: '/messages', label: 'Messages' },
    { href: '/video/room', label: 'Video' },
    { href: '/billing', label: 'Billing' },
  ];
  return (
    <nav className="w-48 min-h-screen bg-white border-r p-4 space-y-2">
      {links.map(({ href, label }) => {
        const active = pathname?.startsWith(href);
        return (
          <Link key={href} href={href}>
            <a
              className={
                'block px-4 py-2 rounded ' +
                (active ? 'bg-brand text-white font-medium' : 'text-gray-700 hover:bg-gray-100')
              }
            >
              {label}
            </a>
          </Link>
        );
      })}
    </nav>
  );
}