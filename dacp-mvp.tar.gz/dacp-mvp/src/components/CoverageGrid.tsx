import React from 'react';

/**
 * CoverageGrid renders a simple grid showing which services are
 * included in the member's subscription.  The `services` prop
 * contains a dictionary where the key is the service name and the
 * value is a boolean indicating whether the service is covered.  In a
 * real implementation you might also include descriptions or tiers.
 */
export default function CoverageGrid({
  services,
}: {
  services: { [service: string]: boolean };
}) {
  const entries = Object.entries(services);
  if (entries.length === 0) {
    return <p className="text-sm text-gray-600">No services found.</p>;
  }
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {entries.map(([name, covered]) => (
        <div
          key={name}
          className="flex items-center p-4 border rounded-lg bg-white shadow-sm"
        >
          <span className="flex-1 text-gray-700">{name}</span>
          {covered ? (
            <span className="text-green-600 font-semibold">Covered</span>
          ) : (
            <span className="text-red-600 font-semibold">Not covered</span>
          )}
        </div>
      ))}
    </div>
  );
}