import './globals.css';
import type { ReactNode } from 'react';

/**
 * RootLayout provides the HTML shell for the entire application.  It
 * applies global styles and metadata and is responsible for rendering
 * whatever page component is currently active.  Since the DACP MVP
 * contains both public pages (landing, sign‑up) and authenticated
 * member/provider dashboards, the individual pages decide when to
 * render sidebars or other navigation.
 */
export const metadata = {
  title: 'Direct Access Care Platform',
  description: 'A minimal telehealth MVP with sign‑up, dashboard, messages and video visits.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        {children}
      </body>
    </html>
  );
}