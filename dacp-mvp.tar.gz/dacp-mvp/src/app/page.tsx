import Link from 'next/link';

/**
 * The landing page is publicly accessible and introduces prospective
 * members to the Direct Access Care Platform.  It highlights the
 * benefits of the service, outlines the subscription pricing and
 * provides a call‑to‑action for sign‑up.  Styling is handled via
 * Tailwind CSS classes defined in `globals.css` and the default theme.
 */
export default function LandingPage() {
  return (
    <main className="flex flex-col items-center justify-start flex-1 p-8">
      <header className="text-center max-w-2xl">
        <h1 className="text-4xl font-bold mb-4 text-brand">Direct Access Care Platform</h1>
        <p className="text-lg text-gray-600 mb-8">
          Affordable and convenient telehealth for everyone.  Sign up
          today to connect with licensed providers via secure video and chat.
        </p>
        <Link href="/signup">
          <a className="inline-block px-6 py-3 bg-brand text-white rounded-md shadow hover:bg-brand/90 transition-colors">
            Get Started
          </a>
        </Link>
      </header>
      <section className="mt-12 w-full max-w-3xl">
        <h2 className="text-2xl font-semibold mb-4">Simple pricing</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 border rounded-lg shadow-sm bg-white">
            <h3 className="text-xl font-bold mb-2">Basic</h3>
            <p className="mb-4 text-gray-500">$29/month</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>Unlimited chat support</li>
              <li>Up to 2 video visits / month</li>
              <li>Access to licensed providers</li>
            </ul>
          </div>
          <div className="p-6 border rounded-lg shadow-sm bg-white">
            <h3 className="text-xl font-bold mb-2">Standard</h3>
            <p className="mb-4 text-gray-500">$49/month</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>Unlimited chat and video visits</li>
              <li>Priority scheduling</li>
              <li>Prescription management</li>
            </ul>
          </div>
          <div className="p-6 border rounded-lg shadow-sm bg-white">
            <h3 className="text-xl font-bold mb-2">Premium</h3>
            <p className="mb-4 text-gray-500">$99/month</p>
            <ul className="space-y-2 text-sm text-gray-600">
              <li>All Standard features</li>
              <li>Dedicated care coordinator</li>
              <li>Specialist referrals</li>
            </ul>
          </div>
        </div>
      </section>
    </main>
  );
}