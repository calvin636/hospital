"use client";

import { useEffect, useRef } from 'react';
import { useParams } from 'next/navigation';
import Sidebar from '@/components/Sidebar';
import { joinVideoRoom } from '@/lib/twilio';

/**
 * The VideoRoomPage hosts a Twilio Video room.  It reads the
 * dynamic room name from the URL and then uses the helper from
 * `lib/twilio` to join the room.  Once connected, the local
 * participant's video is appended to a ref'd container.  Remote
 * participants will automatically be added by the Twilio SDK.  In
 * this MVP stub, error handling is minimal.
 */
export default function VideoRoomPage() {
  const { room } = useParams<{ room: string }>();
  const videoRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!room) return;
    let cleanup: (() => void) | undefined;
    joinVideoRoom(room)
      .then((videoRoom) => {
        cleanup = () => videoRoom.disconnect();
        // Attach local participant's tracks
        videoRoom.localParticipant.videoTracks.forEach(({ track }) => {
          const element = track.attach();
          element.style.width = '100%';
          videoRef.current?.appendChild(element);
        });
        // Listen for new participant connections
        videoRoom.on('participantConnected', (participant) => {
          participant.tracks.forEach((publication) => {
            if (publication.isSubscribed) {
              const element = publication.track.attach();
              element.style.width = '100%';
              videoRef.current?.appendChild(element);
            }
          });
          participant.on('trackSubscribed', (track) => {
            const element = track.attach();
            element.style.width = '100%';
            videoRef.current?.appendChild(element);
          });
        });
      })
      .catch((err) => {
        console.error(err);
      });
    return () => {
      if (cleanup) cleanup();
    };
  }, [room]);
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-6">
        <h1 className="text-2xl font-bold mb-4">Video Room: {room}</h1>
        <div ref={videoRef} className="w-full aspect-video bg-black rounded-lg overflow-hidden"></div>
      </main>
    </div>
  );
}