"use client";

import { useState } from 'react';
import { supabaseBrowserClient } from '@/lib/supabase';

/**
 * The sign‑up page allows a prospective member to create an account
 * using passwordless magic links via Supabase.  After entering an
 * email address, the user will receive a secure sign‑in link that
 * registers them and logs them into the application.  For a full
 * implementation, you would also collect additional profile
 * information such as full name and phone number.  Error handling is
 * intentionally simple for this MVP.
 */
export default function SignupPage() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'sending' | 'sent' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setStatus('sending');
    setErrorMessage(null);
    const supabase = supabaseBrowserClient();
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL || ''}/dashboard`,
      },
    });
    if (error) {
      setErrorMessage(error.message);
      setStatus('error');
    } else {
      setStatus('sent');
    }
  }

  return (
    <main className="flex flex-col items-center justify-center flex-1 p-8">
      <div className="max-w-md w-full bg-white p-8 rounded-lg shadow">
        <h1 className="text-2xl font-bold mb-4 text-center">Sign up</h1>
        <p className="text-sm text-gray-600 mb-6 text-center">
          Enter your email address and we'll send you a secure magic link to
          get started.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            required
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full px-4 py-2 border rounded"
          />
          <button
            type="submit"
            disabled={status === 'sending'}
            className="w-full px-4 py-2 bg-brand text-white rounded shadow hover:bg-brand/90 disabled:opacity-60"
          >
            {status === 'sending' ? 'Sending...' : 'Send magic link'}
          </button>
        </form>
        {status === 'sent' && (
          <p className="text-green-600 mt-4 text-center">Check your email for the magic link!</p>
        )}
        {status === 'error' && errorMessage && (
          <p className="text-red-600 mt-4 text-center">{errorMessage}</p>
        )}
      </div>
    </main>
  );
}