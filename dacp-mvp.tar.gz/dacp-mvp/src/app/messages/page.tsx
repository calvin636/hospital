import Sidebar from '@/components/Sidebar';

/**
 * MessagesPage displays the Twilio Conversations embed for
 * asynchronous messaging between members and providers.  In this
 * MVP stub we show a placeholder; integrate Twilio Conversations
 * by replacing the placeholder with the widget code and adding the
 * appropriate access token logic in a future iteration.
 */
export default function MessagesPage() {
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-6">
        <h1 className="text-2xl font-bold mb-4">Messages</h1>
        <div className="p-4 border rounded-lg bg-white shadow-sm">
          {/* Replace this div with the Twilio Conversations widget */}
          <p className="text-gray-600">Twilio Conversations widget will appear here.</p>
        </div>
      </main>
    </div>
  );
}