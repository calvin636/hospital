import CoverageGrid from '@/components/CoverageGrid';
import Sidebar from '@/components/Sidebar';
import { supabaseAdmin } from '@/lib/supabase';
import Link from 'next/link';

/**
 * The dashboard is the primary home for authenticated members.  It
 * displays personalized information including coverage details from
 * the active subscription, a list of upcoming encounters and
 * billing status.  Server‑side data fetching is used to retrieve
 * the member profile and related data from Supabase.  If no
 * authenticated session is available the user is redirected back to
 * the sign‑up page (logic omitted here for brevity).
 */
export default async function DashboardPage() {
  // Attempt to fetch the current member along with their active
  // subscription contract and upcoming encounters.  If environment
  // variables are not set this will throw and we fall back to stubbed
  // data for demonstration purposes.
  let member: any = null;
  let plan: any = null;
  let encounters: any[] = [];
  try {
    const supabase = supabaseAdmin();
    // In a real implementation, you would identify the current user
    // from the session (e.g. supabase.auth.getUser()).  Here we
    // assume RLS policies restrict the rows returned to the current
    // member.
    const { data: memberData } = await supabase.from('member').select('*').limit(1).single();
    member = memberData;
    // Active subscription contract and plan
    const { data: contractData } = await supabase
      .from('subscription_contract')
      .select('*, subscription_plan(*)')
      .eq('status', 'active')
      .limit(1)
      .single();
    plan = contractData?.subscription_plan;
    // Upcoming encounters (future encounters starting after now)
    const { data: encountersData } = await supabase
      .from('encounter')
      .select('*, provider!inner(full_name)')
      .gte('started_at', new Date().toISOString())
      .order('started_at', { ascending: true })
      .limit(3);
    encounters = encountersData ?? [];
  } catch (error) {
    // If Supabase keys are missing or the query fails, stub out
    // example data so the dashboard still renders meaningfully.
    member = { full_name: 'Test User', state: 'TX' };
    plan = {
      tier_name: 'Standard',
      included_services: {
        'Video visits': true,
        'Unlimited chat': true,
        'Lab orders': false,
      },
    };
    encounters = [
      {
        encounter_id: '1',
        started_at: new Date().toISOString(),
        provider: { full_name: 'Dr. Smith' },
      },
    ];
  }
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-6 space-y-6">
        <h1 className="text-2xl font-bold mb-4">Welcome{member && member.full_name ? `, ${member.full_name}` : ''}</h1>
        {/* Coverage grid */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Coverage</h2>
          {plan && plan.included_services ? (
            <CoverageGrid services={plan.included_services} />
          ) : (
            <p>No subscription plan found.</p>
          )}
        </section>
        {/* Upcoming encounters */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Upcoming visits</h2>
          {encounters.length > 0 ? (
            <ul className="space-y-2">
              {encounters.map((enc) => (
                <li
                  key={enc.encounter_id}
                  className="p-4 border rounded-lg bg-white shadow-sm flex justify-between"
                >
                  <span>{enc.provider?.full_name || 'Provider'}</span>
                  <span className="text-sm text-gray-500">
                    {new Date(enc.started_at).toLocaleString()}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p>No upcoming visits.</p>
          )}
        </section>
        {/* Billing status */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Billing</h2>
          <p className="text-gray-600">
            Your current plan: <span className="font-medium">{plan?.tier_name || 'N/A'}</span>
          </p>
          <Link href="/billing">
            <a className="mt-2 inline-block text-brand hover:underline">View billing history →</a>
          </Link>
        </section>
      </main>
    </div>
  );
}