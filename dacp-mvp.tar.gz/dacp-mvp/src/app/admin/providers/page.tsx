import Sidebar from '@/components/Sidebar';

/**
 * The ProvidersAdminPage is a simple queue view for providers to
 * manage incoming encounter requests.  In this MVP stub, it renders
 * a static list of example encounters.  A future implementation
 * would fetch pending encounters from the database and allow
 * providers to accept or reject them.
 */
export default function ProvidersAdminPage() {
  const queue = [
    { member: 'Jane Doe', reason: 'Follow‑up', requestedAt: new Date().toLocaleString() },
    { member: 'John Smith', reason: 'New patient', requestedAt: new Date().toLocaleString() },
  ];
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-6">
        <h1 className="text-2xl font-bold mb-4">Provider Queue</h1>
        <ul className="space-y-2">
          {queue.map((item, idx) => (
            <li
              key={idx}
              className="p-4 border rounded-lg bg-white shadow-sm flex justify-between"
            >
              <span>
                <span className="font-medium">{item.member}</span> — {item.reason}
              </span>
              <span className="text-sm text-gray-500">{item.requestedAt}</span>
            </li>
          ))}
        </ul>
      </main>
    </div>
  );
}