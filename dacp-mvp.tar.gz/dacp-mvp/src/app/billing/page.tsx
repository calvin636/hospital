import Sidebar from '@/components/Sidebar';
import { supabaseAdmin } from '@/lib/supabase';

/**
 * BillingPage displays the member's subscription contract details and
 * payment history.  Data is fetched server‑side from Supabase or
 * stubbed if the environment variables are not configured.  A future
 * iteration could incorporate Stripe Billing Portal for self‑service
 * plan management.
 */
export default async function BillingPage() {
  let contract: any = null;
  let payments: any[] = [];
  try {
    const supabase = supabaseAdmin();
    const { data: contractData } = await supabase
      .from('subscription_contract')
      .select('*, subscription_plan(*)')
      .eq('status', 'active')
      .limit(1)
      .single();
    contract = contractData;
    const { data: paymentsData } = await supabase
      .from('payment')
      .select('*')
      .eq('contract_id', contractData.contract_id)
      .order('paid_at', { ascending: false })
      .limit(10);
    payments = paymentsData || [];
  } catch (error) {
    // fallback stub
    contract = {
      subscription_plan: { tier_name: 'Standard', monthly_fee: 49.0 },
      start_date: new Date().toISOString().slice(0, 10),
      status: 'active',
    };
    payments = [
      { payment_id: '1', amount: 49.0, currency: 'usd', paid_at: new Date().toISOString() },
    ];
  }
  return (
    <div className="flex">
      <Sidebar />
      <main className="flex-1 p-6 space-y-6">
        <h1 className="text-2xl font-bold">Billing</h1>
        {/* Active subscription */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Active subscription</h2>
          {contract ? (
            <div className="p-4 border rounded bg-white shadow-sm space-y-1">
              <p>
                Plan: <span className="font-medium">{contract.subscription_plan?.tier_name}</span>
              </p>
              <p>
                Status: <span className="font-medium capitalize">{contract.status}</span>
              </p>
              <p>
                Start date: <span className="font-medium">{contract.start_date}</span>
              </p>
            </div>
          ) : (
            <p>No active subscription found.</p>
          )}
        </section>
        {/* Payment history */}
        <section>
          <h2 className="text-xl font-semibold mb-2">Payment history</h2>
          {payments.length > 0 ? (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr>
                  <th className="border-b p-2">Date</th>
                  <th className="border-b p-2">Amount</th>
                  <th className="border-b p-2">Currency</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p) => (
                  <tr key={p.payment_id} className="border-b">
                    <td className="p-2">
                      {new Date(p.paid_at).toLocaleDateString()} {new Date(p.paid_at).toLocaleTimeString()}
                    </td>
                    <td className="p-2">${p.amount}</td>
                    <td className="p-2 uppercase">{p.currency}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <p>No payments found.</p>
          )}
        </section>
      </main>
    </div>
  );
}