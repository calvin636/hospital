import type { NextApiRequest, NextApiResponse } from 'next';
import { stripeServer } from '@/lib/stripe';
import { supabaseAdmin } from '@/lib/supabase';

export const config = {
  api: {
    // Disables Next.js's default body parser so we can retrieve the raw
    // body for signature verification.  See Stripe docs for details.
    bodyParser: false,
  },
};

/**
 * Handles Stripe webhook events for subscription updates.  The
 * endpoint verifies the signature and then updates the
 * subscription_contract table accordingly.  This stub simply logs
 * the event type and acknowledges receipt.  Implement additional
 * logic to handle `invoice.paid`, `customer.subscription.updated`,
 * etc., as needed.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const buf = await getRawBody(req);
  const sig = req.headers['stripe-signature'];
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  try {
    const stripe = stripeServer();
    const event = stripe.webhooks.constructEvent(buf, sig as string, webhookSecret!);
    // Handle subscription events
    switch (event.type) {
      case 'customer.subscription.updated':
      case 'customer.subscription.created':
      case 'customer.subscription.deleted':
        // TODO: update subscription_contract table based on event.data.object
        break;
      default:
        break;
    }
    res.status(200).json({ received: true });
  } catch (err: any) {
    console.error(err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
  }
}

// Reads the raw request body into a Buffer.  Needed for Stripe
// webhook signature verification.
function getRawBody(req: NextApiRequest): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on('data', (chunk) => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}