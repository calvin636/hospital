import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin } from '@/lib/supabase';

/**
 * Returns the profile for the currently authenticated member.  In
 * production, you would use the access token from the request
 * headers or cookies to identify the user and apply row‑level
 * security.  Here we simply fetch the first member row as a stub.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', ['GET']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
    return;
  }
  try {
    const supabase = supabaseAdmin();
    const { data, error } = await supabase.from('member').select('*').limit(1).single();
    if (error) throw error;
    res.status(200).json(data);
  } catch (error: any) {
    // fallback stub
    res.status(200).json({ member_id: 'stub', full_name: 'Test User', email: 'test@example.com' });
  }
}