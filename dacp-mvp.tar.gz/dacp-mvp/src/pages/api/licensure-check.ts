import type { NextApiRequest, NextApiResponse } from 'next';

/**
 * Validates that a provider is licensed to practice in the member's
 * state.  In a real implementation this would query your provider
 * table and potentially an external licensing database.  The MVP
 * returns `true` if the provider has the state in their
 * `licensure_states` array.  When stubbed, it always returns true.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
    return;
  }
  const { providerId, state } = req.body;
  if (!providerId || !state) {
    res.status(400).json({ error: 'providerId and state are required' });
    return;
  }
  // TODO: Implement actual provider licensure check using DB
  res.status(200).json({ valid: true });
}