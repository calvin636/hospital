import type { NextApiRequest, NextApiResponse } from 'next';
import { v4 as uuidv4 } from 'uuid';
import Twilio from 'twilio';

/**
 * Returns a short‑lived access token for joining a Twilio Video room.
 * The request body should include a `room` field specifying the
 * room name.  The token is signed using the API key and secret and
 * grants permission to join the specified room.  See Twilio docs for
 * details: https://www.twilio.com/docs/video/build-js-sdk-applications#generate-access-tokens
 */
export default function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
    return;
  }
  const { room } = req.body;
  if (!room) {
    res.status(400).json({ error: 'room is required' });
    return;
  }
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const apiKey = process.env.TWILIO_API_KEY_SID;
  const apiSecret = process.env.TWILIO_API_KEY_SECRET;
  if (!accountSid || !apiKey || !apiSecret) {
    res.status(500).json({ error: 'Twilio environment variables are missing' });
    return;
  }
  const AccessToken = Twilio.jwt.AccessToken;
  const VideoGrant = AccessToken.VideoGrant;
  const token = new AccessToken(accountSid, apiKey, apiSecret, {
    identity: uuidv4(),
  });
  token.addGrant(new VideoGrant({ room }));
  res.status(200).json({ token: token.toJwt() });
}