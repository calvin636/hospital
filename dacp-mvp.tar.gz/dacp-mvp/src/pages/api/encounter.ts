import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin } from '@/lib/supabase';
import { stripeServer } from '@/lib/stripe';
import Twilio from 'twilio';

/**
 * Creates a new Twilio video room and inserts an encounter row
 * associated with the current member and selected provider.  The
 * request body must include a `providerId` and optionally a
 * `roomName`; if omitted a UUID will be generated.  The response
 * includes the newly created encounter record and room details.  In
 * production you would also verify that the member is eligible for
 * coverage and that the provider is licensed in the member's state.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
    return;
  }
  try {
    const { providerId, roomName } = req.body;
    if (!providerId) {
      res.status(400).json({ error: 'providerId is required' });
      return;
    }
    const name = roomName || `encounter-${Date.now()}`;
    // Create a Twilio video room
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const apiKey = process.env.TWILIO_API_KEY_SID;
    const apiSecret = process.env.TWILIO_API_KEY_SECRET;
    if (!accountSid || !apiKey || !apiSecret) {
      throw new Error('Twilio environment variables are missing');
    }
    const twilioClient = Twilio(apiKey, apiSecret, { accountSid });
    const room = await twilioClient.video.rooms.create({
      uniqueName: name,
      type: 'group',
    });
    // Insert encounter row
    const supabase = supabaseAdmin();
    const { data: encounter, error } = await supabase
      .from('encounter')
      .insert({ provider_id: providerId, covered_flag: true, started_at: null })
      .single();
    if (error) throw error;
    res.status(200).json({ room, encounter });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
}