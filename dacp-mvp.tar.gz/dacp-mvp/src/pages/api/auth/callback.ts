import type { NextApiRequest, NextApiResponse } from 'next';
import { supabaseAdmin } from '@/lib/supabase';

/**
 * Handles Supabase OAuth redirects.  After a user completes the OAuth
 * provider flow they are redirected back to this endpoint with
 * `provider_token` and `provider_refresh_token` query params.  We
 * exchange those for a Supabase session and then redirect the user
 * to the dashboard.
 */
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { provider_token, provider_refresh_token } = req.query;
  if (!provider_token || Array.isArray(provider_token)) {
    res.status(400).send('Missing provider_token');
    return;
  }
  try {
    const supabase = supabaseAdmin();
    const { data, error } = await supabase.auth.exchangeCodeForSession(String(provider_token));
    if (error) throw error;
    // set a cookie with supabase session if desired; omitted here
    res.redirect('/dashboard');
  } catch (error: any) {
    res.status(500).send(error.message);
  }
}