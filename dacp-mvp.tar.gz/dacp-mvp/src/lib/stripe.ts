import { loadStripe, Stripe } from '@stripe/stripe-js';
import StripeServer from 'stripe';

/**
 * Stripe helper utilities.  The `getStripe` function loads the Stripe.js
 * library in the browser using the publishable key.  The
 * `stripeServer` instance can be used in server‑side code to
 * interact with the Stripe API using the secret key.  Both keys
 * should be provided via environment variables.
 */

let stripePromise: Promise<Stripe | null>;
export function getStripe(): Promise<Stripe | null> {
  if (!stripePromise) {
    const pk = process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY;
    if (!pk) throw new Error('Stripe publishable key is missing');
    stripePromise = loadStripe(pk);
  }
  return stripePromise;
}

export function stripeServer() {
  const secret = process.env.STRIPE_SECRET_KEY;
  if (!secret) {
    throw new Error('Stripe secret key is missing');
  }
  return new StripeServer(secret, { apiVersion: '2022-11-15' });
}