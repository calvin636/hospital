import { connect, createLocalVideoTrack, createLocalAudioTrack, Room } from 'twilio-video';

/**
 * Utility functions for interacting with Twilio Video.  To join a
 * video room, call `joinVideoRoom` with a room name.  The client
 * fetches an access token from our own API route at `/api/twilio-token`,
 * creates local audio/video tracks and connects to the room.
 */

export async function joinVideoRoom(roomName: string): Promise<Room> {
  const response = await fetch('/api/twilio-token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ room: roomName }),
  });
  const { token } = await response.json();
  // create local tracks
  const videoTrack = await createLocalVideoTrack();
  const audioTrack = await createLocalAudioTrack();
  return connect(token, {
    name: roomName,
    tracks: [videoTrack, audioTrack],
  });
}