import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Creates and returns a Supabase client instance using the provided
 * environment variables.  Two helper functions are exported:
 *
 *  - `supabaseBrowserClient()` should be called from client‑side
 *    components.  It reads the public URL and anon key from
 *    `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
 *
 *  - `supabaseAdmin()` can be used in server code (API routes or
 *    getServerSideProps) and leverages the `SUPABASE_SERVICE_ROLE_KEY`
 *    for unrestricted access.  Be careful to keep that key on the
 *    server only.
 */

let cachedBrowserClient: SupabaseClient | undefined;
export function supabaseBrowserClient(): SupabaseClient {
  if (!cachedBrowserClient) {
    const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
    if (!url || !anon) {
      throw new Error('Supabase environment variables are missing');
    }
    cachedBrowserClient = createClient(url, anon);
  }
  return cachedBrowserClient;
}

let cachedAdminClient: SupabaseClient | undefined;
export function supabaseAdmin(): SupabaseClient {
  if (!cachedAdminClient) {
    const url = process.env.SUPABASE_URL;
    const serviceRole = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRole) {
      throw new Error('Supabase admin environment variables are missing');
    }
    cachedAdminClient = createClient(url, serviceRole, {
      auth: { persistSession: false },
    });
  }
  return cachedAdminClient;
}