-- DACP MVP database schema for Supabase/Postgres

-- Members
create table if not exists public.member (
  member_id uuid primary key default gen_random_uuid(),
  email text not null unique,
  full_name text,
  phone text,
  state text,
  created_at timestamptz default now()
);

-- Subscription plans
create table if not exists public.subscription_plan (
  plan_id uuid primary key default gen_random_uuid(),
  tier_name text not null,
  monthly_fee numeric(10,2) not null,
  annual_fee numeric(10,2),
  included_services jsonb default '{}'
);

-- Active contracts
create table if not exists public.subscription_contract (
  contract_id uuid primary key default gen_random_uuid(),
  member_id uuid references public.member on delete cascade,
  plan_id uuid references public.subscription_plan,
  status text default 'active',
  start_date date default current_date,
  end_date date,
  stripe_subscription_id text,
  not_insurance_ack boolean default false
);

-- Providers
create table if not exists public.provider (
  provider_id uuid primary key default gen_random_uuid(),
  full_name text,
  specialty text,
  licensure_states text[] default '{}'
);

-- Encounters (video sessions)
create table if not exists public.encounter (
  encounter_id uuid primary key default gen_random_uuid(),
  member_id uuid references public.member on delete cascade,
  provider_id uuid references public.provider,
  covered_flag boolean default true,
  started_at timestamptz default now(),
  ended_at timestamptz
);

-- Messages
create table if not exists public.message (
  message_id uuid primary key default gen_random_uuid(),
  encounter_id uuid references public.encounter on delete cascade,
  sender_id uuid,
  body text,
  sent_at timestamptz default now()
);

-- Payments
create table if not exists public.payment (
  payment_id uuid primary key default gen_random_uuid(),
  contract_id uuid references public.subscription_contract on delete cascade,
  amount numeric(10,2),
  currency text default 'usd',
  method text,
  paid_at timestamptz default now()
);

-- Consents (HIPAA + Not‑Insurance)
create table if not exists public.consent_log (
  consent_id uuid primary key default gen_random_uuid(),
  member_id uuid references public.member on delete cascade,
  consent_type text,
  date_signed timestamptz default now()
);