/**
 * @type {import('next').NextConfig}
 *
 * The Next.js configuration for the DACP MVP.  The experimental `appDir`
 * option enables the new app router introduced in Next.js 13+.  See
 * https://nextjs.org/docs/app for details.
 */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  reactStrictMode: true,
};

module.exports = nextConfig;